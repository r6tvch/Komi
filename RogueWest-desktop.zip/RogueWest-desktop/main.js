const {app,BrowserWindow,Menu}=require('electron');
const path=require('path');
function createWindow(){
  const win=new BrowserWindow({
    width:1280,height:760,minWidth:640,minHeight:400,
    backgroundColor:'#160e08',title:'RogueWest',
    icon:path.join(__dirname,'game','icon.png'),
    autoHideMenuBar:true,
    fullscreen:true,
    webPreferences:{contextIsolation:true,backgroundThrottling:false}
  });
  Menu.setApplicationMenu(null);
  win.loadFile(path.join(__dirname,'game','index.html'));
  // F11 — fullscreen window (in-game "Fullscreen" setting works too)
  win.webContents.on('before-input-event',(e,i)=>{
    if(i.type==='keyDown'&&i.key==='F11'){win.setFullScreen(!win.isFullScreen());e.preventDefault()}
  });
  win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
}
app.whenReady().then(createWindow);
app.on('window-all-closed',()=>app.quit());
