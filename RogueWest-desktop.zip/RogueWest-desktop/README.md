# RogueWest для ПК (версия 5.0)
Electron-обёртка игры. GitHub Actions собирает:
- Windows: RogueWest-Setup.exe (установщик) и RogueWest-Portable.exe (без установки)
- macOS: RogueWest.dmg
- Linux: RogueWest.AppImage
Шрифты встроены, игра работает без интернета. Кнопка «ВЫХОД» в меню закрывает игру, F11 — полный экран.
Локальная сборка: npm install && npm run dist
